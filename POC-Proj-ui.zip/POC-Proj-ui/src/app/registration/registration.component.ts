import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl, NgForm } from '@angular/forms';
import { first } from 'rxjs/operators';
import { RegistrationService} from '../service/registration.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  form = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    age: new FormControl('')
  });

  isWait:boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private registrationService: RegistrationService,
    private route: ActivatedRoute,
    private router: Router
    ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', Validators.required],
      phone: ['', Validators.required],
      gender: ['', Validators.required],
      dob: ['', Validators.required],
      userName: ['', Validators.required],
      password: ['', Validators.required],
      organizationName: ['', Validators.required],
      school: ['', Validators.required],
      pesticides: ['', Validators.required],
      restaurent: ['', Validators.required]
  });
   
  }

  onSubmitRegistration(){
    this.isWait=true;
    console.log("form data :  "+JSON.stringify(this.form.value));
    this.registrationService.onSubmitRegistration(this.form.value)
    .pipe(first())
            .subscribe(
                data => {
                  this.isWait=false;
                  alert("registration completed successfully ");
                    //this.alertService.success('Registration successful', { keepAfterRouteChange: true });
                   // this.router.navigate(['../login'], { relativeTo: this.route });
                   console.log("response data is : "+JSON.stringify(data));
                    this.router.navigate(['/login'], { relativeTo: this.route });
                },
                error => {
                  this.isWait=false;
                  alert("registration failed ");
                    //this.alertService.error(error);
                    //this.loading = false;
                });
  }

}
