import { Injectable } from '@angular/core';
import { Form, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor( private router: Router, private http: HttpClient) { }

  onSubmitLogin(user: User){
    const headers = new HttpHeaders({
      'Content-Type': 'application/json;charset=UTF-8',
      'Authorization': "Basic " + btoa("fooClientId" + ":" + "secret"),
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': '*',
      'Access-Control-Allow-Methods': '*'
      });
    return this.http.post(`${environment.apiUrl}/user`, user,{'headers':headers});
    
  }

  
  login(user: User): Observable<any> {
    
    
    const body = new HttpParams()
      .set('grant_type', 'password')
      .set('username', user.userName)
      .set('password', user.password);
      
      /*const headers = new HttpHeaders({
        'Content-Type': 'application/json;charset=UTF-8',
        'Authorization': "Basic " + btoa("fooClientId" + ":" + "secret"),
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': '*',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Credentials':'true',
       
        });
    return this.http.post<any>(`${environment.apiUrl}/oauth/token?grant_type=password&username=${user.userName}&password=${user.password}`,null,{'headers':headers});
        */
    return this.http.get<any>(`${environment.apiUrl}/login?username=${user.userName}&password=${user.password}`);
  }

  getUserDetails(): Observable<any> {

    //return this.http.get<any>(`https://cors-anywhere.herokuapp.com/${environment.apiUrl}/username`);;
    return this.http.get<any>(`${environment.apiUrl}/userdetails`);;
  }

}
