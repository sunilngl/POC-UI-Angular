import { getAttrsForDirectiveMatching } from "@angular/compiler/src/render3/view/util";

export class User {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    gender: string;
    dob: string;
    userName: string;
    password: string;
    organizationName: string;
    school: boolean;
    pesticides: boolean;
    schrestaurentool: boolean;
    role: string = "ADMIN";
    enabled:number = 1;
}
