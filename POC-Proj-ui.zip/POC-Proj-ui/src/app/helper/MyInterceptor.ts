import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpResponse }
  from '@angular/common/http';
  import { Router } from '@angular/router';

import { Observable } from 'rxjs';
//import 'rxjs/add/operator/';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';
@Injectable()
export class MyInterceptor implements HttpInterceptor {

    constructor(
        private router: Router
      ) { }
    intercept(
        request: HttpRequest<any>, next: HttpHandler
      ) : Observable<HttpEvent<any>> {
        //const storageUser = localStorage.getItem('LoggedUser');
       //const loggedUser = jsonInfo ? JSON.parse(jsonInfo) : null;
       let auth =  "Basic " + btoa("fooClientId" + ":" + "secret");
       if (sessionStorage.getItem("access_token") != null) {
            auth = "bearer "+sessionStorage.getItem("access_token");
       }

       console.log("before request is  :"+JSON.stringify(request));
       if(sessionStorage.getItem("access_token") != null){
          request = request.clone({
            setHeaders: {
                
                'Content-Type': 'application/json;charset=UTF-8',
                'Authorization': "bearer "+sessionStorage.getItem("access_token"),
               
                //'Referrer-Policy':origin
                }
            });
        }else{
          request = request.clone({
            setHeaders: {
                //Authorization: `Bearer ${user.token}`,
                'Content-Type': 'application/json;charset=UTF-8',
                'Authorization': "Basic " + btoa("fooClientId" + ":" + "secret"),
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': '*',
                'Access-Control-Allow-Credentials':'true',
                }
            });

          }
       
        
          console.log("after request is  :"+JSON.stringify(request));
        return next.handle(request).pipe(
            catchError(error => {
              // Checking if it is an Authentication Error (401)
              if (error.status === 401) {
                alert('Access Denied');
                // <Log the user out of your application code>
                this.router.navigate([ '/login' ]);
                return throwError(error);
              }
              // If it is not an authentication error, just throw it
              return throwError(error);
            })
          );
      }
}