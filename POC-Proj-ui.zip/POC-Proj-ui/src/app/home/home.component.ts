import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { LoginService} from '../service/login.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  userData: any;

  constructor(private route: ActivatedRoute,private router: Router, private loginService: LoginService,) {}

  ngOnInit(): void {
    
    if(sessionStorage.getItem("auth") != null){

    
    this.loginService.getUserDetails()
    .pipe(first())
            .subscribe(
                data => {
                  this.userData = data;
                    console.log(" token data is : "+JSON.stringify(data));
                    //this.router.navigate(['/home'], { relativeTo: this.route });
                },
                error => {
                  console.log("error is  : "+JSON.stringify(error));
                  //alert("login failed ");
                });

              }else{
               this.router.navigate(['/login'], { relativeTo: this.route });
              }
  }

}
