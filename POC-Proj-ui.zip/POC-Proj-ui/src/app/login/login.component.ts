import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormControl, NgForm } from '@angular/forms';
import { first, tap } from 'rxjs/operators';
import { LoginService} from '../service/login.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form = new FormGroup({
    firstName: new FormControl(''),
    lastName: new FormControl(''),
    age: new FormControl('')
  });

  isWait:boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private route: ActivatedRoute,
    private router: Router
    ) {}

  ngOnInit(): void {
    this.form = this.formBuilder.group({
      
      userName: ['', Validators.required],
      password: ['', Validators.required],
      
  });
  }

  onSubmitLogin(){
    //console.log("form data :  "+JSON.stringify(this.form.value));
    this.isWait = true;
    this.loginService.login(this.form.value)
    .pipe(first())
            .subscribe(
                data => {
                  this.isWait = false;
                  alert("login failed ");
                    console.log(" token data is : "+JSON.stringify(data));
                    if(data === "login failed"){
                      alert("login failed ");
                    }else{
                    //this.router.navigate(['/home'], { relativeTo: this.route });
                    }
                },
                error => {
                  this.isWait = false;
                  console.log("erro***"+error)
                  if(error === "login failed"){
                    alert("login failed ");
                  }else{
                    sessionStorage.setItem("auth","true");
                  this.router.navigate(['/home'], { relativeTo: this.route });
                  }
                  
                  
                });
  }

  onSubmitLogin_dup(){
    console.log("form data :  "+JSON.stringify(this.form.value));
    
    this.loginService.login(this.form.value)
    .pipe(
      tap(res => {
        console.log(res);
        // this.tokenService.saveToken(res.access_token);
        // this.tokenService.saveRefreshToken(res.refresh_token);
      }),
      //catchError(AuthService.handleError)
    );
  }
}
